-- SSMS'te yeni sorgu penceresine yapıştırıp çalıştır.
-- Not: Uygulama tabloları yoksa kendisi de oluşturur, ama veritabanını oluşturmaz.
IF DB_ID(N'RestoranDB') IS NULL
    CREATE DATABASE RestoranDB;
GO
USE RestoranDB;
GO
IF OBJECT_ID(N'dbo.BolgeSayim', N'U') IS NULL
CREATE TABLE dbo.BolgeSayim (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Zaman DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    BolgeAdi NVARCHAR(50) NOT NULL,
    KisiSayisi INT NOT NULL
);
GO
IF OBJECT_ID(N'dbo.MasaDurum', N'U') IS NULL
CREATE TABLE dbo.MasaDurum (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Zaman DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    MasaAdi NVARCHAR(50) NOT NULL,
    Durum NVARCHAR(10) NOT NULL
);
GO
